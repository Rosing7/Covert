public interface DiscountRate {
    double getServiceMemberDiscount();
    double getProductMemberDiscount();
}
